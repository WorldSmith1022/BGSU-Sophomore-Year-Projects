#include <cassert>
#include <iostream>
#include <cmath> // I am including this for the pow() function
#include "simplepoly.h"

using namespace std;

simplepoly::simplepoly()
{
	// Pre: None.
	// Post: A basic "zero" polynomial object is created
	// with zero terms (linked list is just a null ptr).  Variable is assumed to be x.

	variable = 'x';
	terms = nullptr;
};

void simplepoly::InsertTermSorted(term t) {
	// Pre: t is a term that has been passed to this function.
	// Post: A new node using term t has been inserted into the function (in the correct order)
	list_insert_sorted(terms, t);
}

void simplepoly::copy(const simplepoly& p)
{
	// Pre: p is a valid polynomial.
	// Post: p is DEEP-COPIED into the implicit parameter.

	// Copy the character value for the variable. 
	variable = p.variable;

	node* tail;

	// Copy the the value of the original linked list into the new one
	list_copy(p.terms, terms, tail);
	
};

simplepoly::simplepoly(const simplepoly& p) //DEEP COPY SEMANTICS
{
	// Pre: p is a valid polynomial.
	// Post: p is copied into the implicit parameter
	// using "deep copy semantics."

	copy(p);
};

void simplepoly::free(void)
{
	// Pre: The implicit parameter has been allocated.
	// Post: Any necessary deallocation is done.

// *DO: FILL IN WITH AN APPROPRIATE IMPLEMENTATION
	list_clear(terms);
};

simplepoly::~simplepoly(void)
{
	// Pre: The implicit parameter has been allocated.
	// Post: Any necessary deallocation is done.

	free();
};

simplepoly& simplepoly::operator= (const simplepoly& p) //DEEP COPY SEMANTICS
{
	// Pre: p is a valid polynomial.
	// Post: The value of p is assigned to the implicit parameter
	// by "deep copy semantics."  Any necessary deallocation is
	// done along the way.

	if (this != &p)
	{
		free();
		copy(p);
	};
	return (*this);
};

void simplepoly::read()
{
	// Pre: None.
	// Post: A new value is read into the implicit paramter polynomial, per
	// instructions as given out first.  If needed, the old value is destroyed.

	simplepoly temp;
	int coeff;
	int exp;
	cout << "Input a polynomial by specifying the variable and all terms in any order." << endl
		<< "Each term is specified by an integer coefficient and" << endl
		<< "a non-negative integer exponent." << endl
		<< "Indicate END by specifying a dummy term with" << endl
		<< "a zero coefficient and/or a negative exponent." << endl;
	cin >> temp.variable;
	do
	{
		cin >> coeff;
		if (coeff)
		{
			cin >> exp;
			if (exp >= 0) {
				term t = term(coeff, exp);
				temp.InsertTermSorted(t);
			}
		}
		else
			while (cin && (cin.peek() != '\n')) cin.ignore();
	} while (coeff && (exp >= 0));

	*this = temp; // The assignment operator is being called here!
};


void simplepoly::write() const
{
	// Pre: The implicit parameter (this) is a valid polynomial (possibly zero).
	// Post: The polynomial represented by the implicit parameter (this) is
	// printed out on the standard output.  The variable is used as stored.

	// Start with the head pointer
	node* curr_ptr = terms;

	// Continue this loop until there are no more terms in the polynomial
	while (curr_ptr != nullptr) {

		// Terms with a coefficient of 0 do not need to be printed. 
		if (curr_ptr->data().coeff != 0) {

			// Print out the sign of the term. If this is the first term, only print out the sign if it is negative.
			// Since the negative sign is automatically printed if the coefficient is below 0, we only need to worry about
			// printing the sign if the coefficient is positive. That way, we don't accidentally print "--4x3" or something.
			if (curr_ptr != terms && curr_ptr->data().coeff > 0) {
				cout << curr_ptr->data().sign();
			}

			// Print the coefficient
			cout << curr_ptr->data().coeff;

			// If the exponent is 1, do not print the exponent. If it is 0, do not print the variable or exponent.
			if (curr_ptr->data().exp > 0) {
				if (curr_ptr->data().exp == 1) { cout << variable; }
				else { cout << variable << curr_ptr->data().exp; }
			}
			// Print out a space between each term
			cout << ' ';
		}
	

		// Move onto the next term (if there is one)
		if (curr_ptr->link() != nullptr) { curr_ptr = curr_ptr->link(); }
		else { 
			curr_ptr = nullptr;
		};

	}

	// If there are no terms in the polynomial (or if it simply hasn't been created yet), print out 0.
	if (terms == nullptr) {
		cout << "0";
	}

	cout << endl;
};


simplepoly simplepoly::plus(simplepoly right) const
{
	// Pre: The implicit parameter and the parameter right are valid
	// polynomials.
	// Post: The sum of the two parameters is returned by plus.

	// This polynomial will be the resulting sum of the two polynomials
	simplepoly sum;
	sum.copy(*this); // Start by copying the left poly into the sum

	// Check to ensure the right polynomial is not empty. If it is, return the left polynomial.
	if (right.terms == NULL) {
		return sum;
	}
	// Check to ensure the left polynomial is not empty. If it is, return the right polynomial.
	if (terms == NULL) {
		return right;
	}

	// Term for the new node entries
	term t;

	// This ptr to a node will be the "index" going through each node in the right polynomial. Starts with the head node of the left poly.
	node* curr_right_node = right.terms;
	// This ptr to a node will be the "index" going through each node in the left polynomial when searching for like terms.
	node* search_left_node;

	// Boolean value for if the current term in the right polynomial has a like term to be added to
	bool isLikeTerm;

	// Go through every node from the right polynomial. 
	// For each one, see if a like term can be found within the sum polynomial.
	// If there is a like term node in sum, add the coeff of the right node to the 
	// coeff of the node in sum.
	// If there is no like term, insert a new node into dif with the exp and coeff of the right node
	while (curr_right_node != NULL) {
		// Term for the new node entries
		term t;
		isLikeTerm = false;
		search_left_node = sum.terms;

		// Search for a like term for the current node to be added tp
		while (search_left_node != NULL) {
			// Break the loop early if we go lower than the exponent we are searching for
			if (search_left_node->data().exp < curr_right_node->data().exp) {
				break;
			}
			// If we find a like term, add to that node
			if (search_left_node->data().exp == curr_right_node->data().exp) {
				isLikeTerm = true;
				t = search_left_node->data();
				t.coeff += curr_right_node->data().coeff;
				search_left_node->set_data(t);
				break;
			}
			// Move onto the next search node
			search_left_node = search_left_node->link();
		}
		// If no like term is found, insert a new node w/ the right node's data
		if (isLikeTerm == false) {
			t = curr_right_node->data();
			if (t.coeff != 0) { sum.InsertTermSorted(t); } // Insert the node (if it is valid)
		}

		// Move onto the next node to be subtracted
		curr_right_node = curr_right_node->link();
	}

	// Using a while loop, go back through the sum polynomial and delete any nodes with a coefficient of zero
	search_left_node = sum.terms;
	
	// If nothing is left of the polynomial, return an empty polynomial
	if (sum.terms == NULL) {
		return simplepoly();
	}
	while (sum.terms != NULL && search_left_node != NULL) {
		// First, check to see if the head node has a coeff = 0. If so, remove the head.
		// If we remove the head we will NOT move ahead to the next node. 
		// We will continue to remove the head of the list until the head has a valid coeff.
		if (sum.terms->data().coeff == 0) {
			list_head_remove(sum.terms);
			search_left_node = sum.terms; // Set search_left_node to the new head of the list
		}
		// Once the head node has a valid coefficient, go through the rest of the list.
		else {
			// Check to see if the node after the current one has a coefficient of zero. 
			// If the current node is the tail, there is a different procedure for removing it (if it needs to be removed)
			if (search_left_node->link() != NULL) {
				// Remove the node after the current one
				if (search_left_node->link()->data().coeff == 0) { 
					list_remove(search_left_node); 
				}
				// Move onto the next node
				else { search_left_node = search_left_node->link(); }
			}
			// Procedure for removing the tail if need be
			else {
				if (search_left_node->data().coeff == 0) { 
					delete search_left_node; 
				}
				break;
			}
		}
		// If nothing is left of the polynomial, return an empty polynomial
		if (sum.terms == NULL) {
			return simplepoly();
		}
	}

	// Return the sum of the two polynomials as a new polynomial
	return sum;
};


simplepoly simplepoly::minus(simplepoly right) const
{
	// Pre: The implicit parameter and the parameter right are valid
	// ploynomials.
	// Post: The difference of the two parameters is returned by minus.
	// The polynomial right is subtracted from the implicit parameter.

	// This polynomial will be the resulting difference of the two polynomials
	simplepoly dif;
	// Start by copying the left polynomial into the difference polynomial
	dif.copy(*this);

	// Check to ensure the right polynomial is not empty. If it is, return the left polynomial.
	if (right.terms == NULL) {
		return dif;
	}
	// Check to ensure the left polynomial is not empty. If it is, return the negative of the right polynomial.
	if (terms == NULL) {
		node* curr_node = right.terms;
		while (curr_node != NULL) {
			term t;
			t.exp = curr_node->data().exp; // Get the exponent
			t.coeff = (0 - curr_node->data().coeff); // Get the coefficient
			if (t.coeff != 0) { dif.InsertTermSorted(t); } // Insert the node (if it is valid)
			curr_node = curr_node->link(); // Move to the next node
		}
		return dif;
	}

	// Boolean value for if the current term in the right polynomial has a like term to be subtracted to
	bool isLikeTerm;

	// Go through every node from the right polynomial. 
	// For each one, see if a like term can be found within the difference polynomial.
	// If there is a like term node in dif, subtract the coeff of the right node from the 
	// coeff of the node in dif.
	// If there is no like term, insert a new node into dif with the exp and NEGATIVE coeff of the right node
	node* curr_right_node = right.terms;
	node* search_left_node;
	while (curr_right_node != NULL) {
		// Term for the new node entries
		term t;
		isLikeTerm = false;
		search_left_node = dif.terms;

		// Search for a like term for the current node to be subtracted from
		while (search_left_node != NULL) {
			// Break the loop early if we go lower than the exponent we are searching for
			if (search_left_node->data().exp < curr_right_node->data().exp) {
				break;
			}
			// If we find a like term, subtract from that node
			if (search_left_node->data().exp == curr_right_node->data().exp) {
				isLikeTerm = true;
				t = search_left_node->data();
				t.coeff -= curr_right_node->data().coeff;
				search_left_node->set_data(t);
				break;
			}
			// Move onto the next search node
			search_left_node = search_left_node->link();
		}
		// If no like term is found, subtract from zero and insert a new node
		if (isLikeTerm == false) {
			t.exp = curr_right_node->data().exp; // Get the exponent
			t.coeff = (0 - curr_right_node->data().coeff); // Get the coefficient
			if (t.coeff != 0) { dif.InsertTermSorted(t); } // Insert the node (if it is valid)
		}

		// Move onto the next node to be subtracted
		curr_right_node = curr_right_node->link();
	}

	// Using a while loop, go back through the difference polynomial and delete any nodes with a coefficient of zero
	search_left_node = dif.terms;

	// If nothing is left of the polynomial, return an empty polynomial
	if (dif.terms == NULL) {
		return simplepoly();
	}

	while (dif.terms != NULL && search_left_node != NULL) {
		// First, check to see if the head node has a coeff = 0. If so, remove the head.
		// If we remove the head we will NOT move ahead to the next node. 
		// We will continue to remove the head of the list until the head has a valid coeff.
		if (dif.terms->data().coeff == 0) {
			list_head_remove(dif.terms);
			search_left_node = dif.terms; // Set search_left_node to the new head of the list
		}
		// Once the head node has a valid coefficient, go through the rest of the list.
		else {
			// Check to see if the node after the current one has a coefficient of zero. 
			// If the current node is the tail, there is a different procedure for removing it (if it needs to be removed)
			if (search_left_node->link() != NULL) {
				// Remove the node after the current one
				if (search_left_node->link()->data().coeff == 0) { 
					list_remove(search_left_node);
				}
				// Move onto the next node
				else { search_left_node = search_left_node->link(); }
			}
			// Procedure for removing the tail if need be
			else {
				if (search_left_node->data().coeff == 0) { 
					delete search_left_node; 
				}
				break;
			}
		}
		// If nothing is left of the polynomial, return an empty polynomial
		if (dif.terms == NULL) {
			return simplepoly();
		}
	}

	// Return the difference of the two polynomials as a new polynomial
	return dif;
};


float simplepoly::evaluate(float value) const
{
	// Pre: The implicit parameter is a valid polynomial.
	// Post: The value of the polynomial with the value substituted for the variable is returned.

	// Using a while loop, evaluate each node/term of the polynomial if variable x is equal to value.

	float result = 0.0;
	float termValue;
	node* curr_node = terms;

	// Going downwards, work through every exponent value until the exponent is equal to 0. 
	while (curr_node != NULL) {
		// Reset the value of termValue
		termValue = 0.0;

		// No need to bother with terms with coefficients of 0; they are not included in these polynomials.
		if (curr_node->data().coeff != 0) {

			// First, find out what the value to the 'exp' power is equal to using the pow() function.
			termValue = pow(value, curr_node->data().exp);
			// Then, multiply by the coefficient
			termValue *= curr_node->data().coeff;
			// Finally, add the value of the term to the total result
			result += termValue;
		}

		// Move onto the next node
		curr_node = curr_node->link();
	}

	// Return the result
	return result;
	
};


// I created this accessor function so that simplepolydr can access a simplepoly object's variable value.
char simplepoly::getVariable() {
	return variable;
}
