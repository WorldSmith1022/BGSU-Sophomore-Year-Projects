// Norman Labow
// Lab 5 - Page Faults

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <iostream>

#define FIFO 0
#define LRU 1
#define NUM_REF 80
#define FRAME_START 3
#define FRAME_END 7

int Ref[NUM_REF] = {
	1, 2, 7, 1, 2, 3, 4, 5, 7, 8,
	9, 7, 2, 1, 3, 7, 2, 3, 2, 1,
	4, 5, 6, 7, 8, 9, 6, 3, 1, 2,
	3, 6, 7, 5, 6, 3, 4, 3, 4, 3,
	4, 3, 4, 3, 4, 7, 7, 2, 1, 7,
	6, 7, 8, 7, 8, 9, 7, 8, 2, 7,
	8, 3, 5, 3, 5, 7, 1, 3, 1, 3,
	1, 3, 2, 3, 4, 5, 6, 7, 8, 9
};

int pf_record[2][5];	// Record of cases as a 2D array. 
			// # of algorithms VS # of cases
			// Using frames 3, 4, 5, 6, and 7

// Function Declarations
void FIFO_Sim();
void LRU_Sim();
void Print();

int main() {
	// Initialize pf_record
	for(int c = 0; c < 2; ++c) {
		for (int f = 0; f < 5; ++f) {
			pf_record[c][f] = -1;
		}
	}

	// Call sims and print info
	FIFO_Sim();
	LRU_Sim();
	Print();

	return 0;
}

// Function Definitions

// Page Replacement using First In First Out algorithm
void FIFO_Sim() {
	int c, r, f; 		// Loop variables
	int Num_Frames;		// Number of available frames for each case
	int page_faults;	// Number of page faults
	int found = 0;		// 0 = not found; 1 = found

	Num_Frames = FRAME_START;

	// For loop from case 1 to 5
	for (c = 0; c < 5; ++c) {
		page_faults = 0; // Reset # of page faults
		int ram_frames[Num_Frames]; // This array represents all RAM frames

		// Initialize/Reset the frames
		for (f = 0; f < Num_Frames; ++f) { ram_frames[f] = -1; }

		// For loop to each reference
		for (r = 0; r < NUM_REF; ++r) {

			found = 0; // Page is not found by default

			// For loop to search if the ref is in the RAM
			for (f = 0; f < Num_Frames; ++f) {
				if (Ref[r] == ram_frames[f]) {
					found = 1; // Mark as found
					--page_faults; // # of faults will not increase
				}
			}
			++page_faults; // Increment # of faults (net 0 if found)

			// If not found and a frame is available
			if((page_faults <= Num_Frames) && (found == 0)) {
				ram_frames[r] = Ref[r];
			}
			// If not found and no frame is available, replace oldest page
			else if (found == 0) {
				ram_frames[((page_faults - 1) % Num_Frames)] = Ref[r];
			}
		}

		// Increase # of available frames
		++Num_Frames;
		
		// Record the number of page faults for this case
		pf_record[FIFO][c] = page_faults;
	}

	return;
}

// Page Replacement using Least Recently Used algorithm
void LRU_Sim() {

	int c, r, f, pos, s, g;
	int a = 0, b = 0, page_faults = 0;
	int Num_Frames = FRAME_START;

	// For loop for every case (# of frames)
	for (c = 0; c < 5; ++c) {
		
		int ram_frames[Num_Frames];
		int temp[Num_Frames];
		page_faults = 0;

		// Reset all frames
		for (f = 0; f < Num_Frames; ++f) { ram_frames[f] = -1; }

		// Go through every reference page
		for (r = 0; r < NUM_REF; ++r) {
			a = 0, b = 0;
			// Look through every frame to see if the page is in
			for (f = 0; f < Num_Frames; ++f) {
				// If the page is in
				if (ram_frames[f] == Ref[r]) {
					a = 1, b = 1;
					break;
				}
			}
			// If it is not yet found
			if (a == 0) {
				// Look to see if any frames have not been used yet (-1)
				for (f = 0; f < Num_Frames; ++f) {
					// If unused frame is found
					if (ram_frames[f] == -1) {
						ram_frames[f] = Ref[r];
						b = 1;
						++page_faults;
						break;
					}
				}
			}
			// If no unused frames are present, find least recently used frame
			if (b == 0) {
				// Initialize temp arrary
				for (f = 0; f < Num_Frames; ++f) { temp[f] = 0; }
				
				// Use for loop to determine which frame is used the least
				for (s = (r - 1), g = 1; g < Num_Frames; ++g, --s) {
					for (f = 0; f < Num_Frames; ++f) {
						if(ram_frames[f] == Ref[s]) { temp[f] = g; }
					}
				}
				// Replace the page at the least recently used frame
				for (f = 0; f < Num_Frames; ++f) {
					if (temp[f] == 0) { pos = f; }
				}
				ram_frames[pos] = Ref[r];
				++page_faults;
			}
		}
		// Record # of page faults
		pf_record[LRU][c] = page_faults;
		// Increment # of frames
		++Num_Frames;
	}

	return;
}

// Print out results of using each algorithm and with certain #'s of frames
void Print() {

	printf("Page Replacement Algorithm Evaluation Results\n");

	printf("\nFIFO Results:\n");
	
	int Num_Frames = FRAME_START;
	
	for (int i = 0; i < 5; ++i) {
		printf("Frame Number %i: %d Page Faults\n", Num_Frames, pf_record[FIFO][i]);
		++Num_Frames;
	}

	printf("\nLRU Results:\n");

	Num_Frames = FRAME_START;
	for (int i = 0; i < 5; ++i) {
		printf("Frame Number %i: %d Page Faults\n", Num_Frames, pf_record[LRU][i]);
		++Num_Frames;
	}
	
	int min_alg = FIFO;
	int pf = 1000;
	int fn = 8;

	for(int i = 0; i < 5; ++i) {
		if (pf_record[FIFO][i] < pf) { 
			pf = pf_record[FIFO][i];
			fn = i + 3;
			min_alg = FIFO;
		}
		if (pf_record[LRU][i] < pf) {
			pf = pf_record[LRU][i];
			fn = i + 3;
			min_alg = LRU;
		}
	}
	if (min_alg == LRU) {
		printf("\nMinimum Page Fault: Algorithm LRU with ");
	}
	else {
		printf("\nMinimum Page Fault: Algorithm FIFO with ");
	}
	printf("%d faults and Frame Number %d\n", pf, fn);
	
	return;
}
