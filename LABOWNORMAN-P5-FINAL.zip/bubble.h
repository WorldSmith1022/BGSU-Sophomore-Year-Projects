#pragma once
int bubblesort(int data[], size_t n);