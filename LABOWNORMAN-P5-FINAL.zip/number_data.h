#pragma once
void fill_random_numbers(int [], const unsigned int);
void fill_sorted_numbers(int[], int[], const unsigned int);