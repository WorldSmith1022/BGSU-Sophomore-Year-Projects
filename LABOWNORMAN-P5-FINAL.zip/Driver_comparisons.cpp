// Created by Norman Labow
// Project 5 - Due 11/9/2022
// Driver to print the number of data comparisons made by each sorting algorithm 
// to a file, compsout.txt

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cmath>
#include "number_data.h"
#include "quick.h"
#include "select.h"
#include "merge.h"
#include "heapsort.h"
#include "insertion.h"
#include "bubble.h"

using namespace std;

int main() {

	// Create output filestreams
	ofstream compsout;
	// Open file, check to ensure it opens
	compsout.open("compsout.txt");
	if (!compsout.is_open()) {
		cout << "Could not open compsout.txt. Ending program." << endl;
		return 1;
	}

	// Due to stack overflow exceptions, I went with significantly lower size limits.
	// First, create input data sets of sizes 1000, 2000, 4000, and 4000 for the following:
	// a. Random Data
	// b. Reverse (descending) sorted data
	// c. 4000 elements of (ascending) sorted data

	// Declare all three arrays of size 4000
	int rnd[4000];
	int dsc[4000];
	int asc[4000];

	// Estimated worst, avg, and best case # of comparisons made
	double worst_count;
	double avg_count;
	double best_count;

	// Initialize the arrays
	fill_random_numbers(rnd, 4000);
	fill_sorted_numbers(asc, dsc, 4000);

	// Use a for loop and switch statement to go through each sorting algorithm
	for (int i = 0; i < 6; ++i) {

		// Use a switch statement to determine which sorting algorithm to use, and print the estimated and actual values
		switch (i) {
		case 0: // Quicksort 
			compsout << "\t --- Quicksort ---" << endl;
			for (int n = 1000; n <= 4000; (n += 1000)) {
				// Declare and initialize three arrays that will be local copies of each specific dataset
				int rnd_copy[4000];
				int dsc_copy[4000];
				int asc_copy[4000];
				for (int j = 0; j < n; ++j) { 
					rnd_copy[j] = rnd[j];
					dsc_copy[j] = dsc[j];
					asc_copy[j] = asc[j];
				}

				// Calculate worst, avg, and best case # of comparisons based on size
				// Runtime is typically N * log2(N) comparisons
				// Worst case is O(n^2)
				// Best case would be when everything is random, so same as average.
				worst_count = pow(n, 2);
				avg_count = (n * log2(static_cast<double>(n)));
				best_count = worst_count;

				// Output to the file the required data

				compsout << fixed << setprecision(3) << n << '\t' << worst_count << '\t' << avg_count << '\t' << best_count << '\t' << quicksort(dsc_copy, n) << '\t' << quicksort(rnd_copy, n);
				if (n != 4000) { compsout << '\t' << '-'; }
				else { compsout << '\t' << quicksort(asc_copy, n); }
				compsout << endl;
			}
			compsout << '\n' << endl;
			break;

		case 1: // Selection Sort
			compsout << "\t --- Selection Sort ---" << endl;
			for (int n = 1000; n <= 4000; (n += 1000)) {
				// Declare and initialize three arrays that will be local copies of each specific dataset
				int rnd_copy[4000];
				int dsc_copy[4000];
				int asc_copy[4000];
				for (int j = 0; j < n; ++j) {
					rnd_copy[j] = rnd[j];
					dsc_copy[j] = dsc[j];
					asc_copy[j] = asc[j];
				}

				// Calculate worst, avg, and best case # of comparisons based on size
				// Runtime is typically N * log2(N) comparisons
				// Worst case is O(n^2)
				// Best case would be when everything is already sorted, (n * (n + 1)) / 2 comparisons
				worst_count = pow(n, 2.0);
				avg_count = (n * log2(static_cast<double>(n)));
				best_count = static_cast<double>(n * (n + 1.0)) / 2.0;

				// Output to the file the required data

				compsout << fixed << setprecision(3) << n << '\t' << worst_count << '\t' << avg_count << '\t' << best_count << '\t' << selectionsort(dsc_copy, n) << '\t' << selectionsort(rnd_copy, n);
				if (n != 4000) { compsout << '\t' << '-'; }
				else { compsout << '\t' << selectionsort(asc_copy, n); }
				compsout << endl;
			}
			compsout << '\n' << endl;
			break;

		case 2: // Merge Sort
			compsout << "\t --- Merge Sort ---" << endl;
			for (int n = 1000; n <= 4000; (n += 1000)) {
				// Declare and initialize three arrays that will be local copies of each specific dataset
				int rnd_copy[4000];
				int dsc_copy[4000];
				int asc_copy[4000];
				for (int j = 0; j < n; ++j) {
					rnd_copy[j] = rnd[j];
					dsc_copy[j] = dsc[j];
					asc_copy[j] = asc[j];
				}

				// Calculate worst, avg, and best case # of comparisons based on size
				// Runtime is typically N * log2(N) comparisons
				// Worst case is O(n^2)
				// Best case would be when everything is random, so same as average.
				worst_count = pow(n, 2);
				avg_count = (n * log2(static_cast<double>(n)));
				best_count = worst_count;

				// Output to the file the required data

				compsout << fixed << setprecision(3) << n << '\t' << worst_count << '\t' << avg_count << '\t' << best_count << '\t' << mergesort(dsc_copy, n) << '\t' << mergesort(rnd_copy, n);
				if (n != 4000) { compsout << '\t' << '-'; }
				else { compsout << '\t' << mergesort(asc_copy, n); }
				compsout << endl;
			}
			compsout << '\n' << endl;
			break;

		case 3: // Heapsort
			compsout << "\t --- Heapsort ---" << endl;
			for (int n = 1000; n <= 4000; (n += 1000)) {
				// Declare and initialize three arrays that will be local copies of each specific dataset
				int rnd_copy[4000];
				int dsc_copy[4000];
				int asc_copy[4000];
				for (int j = 0; j < n; ++j) {
					rnd_copy[j] = rnd[j];
					dsc_copy[j] = dsc[j];
					asc_copy[j] = asc[j];
				}

				// Calculate worst, avg, and best case # of comparisons based on size
				// Worst, Avg, and Best case are all n * log2(n)
				worst_count = (n * log2(static_cast<double>(n)));;
				avg_count = (n * log2(static_cast<double>(n)));
				best_count = (n * log2(static_cast<double>(n)));

				// Output to the file the required data

				compsout << fixed << setprecision(3) << n << '\t' << worst_count << '\t' << avg_count << '\t' << best_count << '\t' << heapsort(dsc_copy, n) << '\t' << heapsort(rnd_copy, n);
				if (n != 4000) { compsout << '\t' << '-'; }
				else { compsout << '\t' << heapsort(asc_copy, n); }
				compsout << endl;
			}
			compsout << '\n' << endl;
			break;

		case 4: // Bubble Sort
			compsout << "\t --- Bubble Sort ---" << endl;
			for (int n = 1000; n <= 4000; (n += 1000)) {
				// Declare and initialize three arrays that will be local copies of each specific dataset
				int rnd_copy[4000];
				int dsc_copy[4000];
				int asc_copy[4000];
				for (int j = 0; j < n; ++j) {
					rnd_copy[j] = rnd[j];
					dsc_copy[j] = dsc[j];
					asc_copy[j] = asc[j];
				}

				// Calculate worst, avg, and best case # of comparisons based on size
				// Average case is O(n) comparisons
				// Worst case is O(n)
				// Best case would be when everything is already sorted, O(n) comparisons
				worst_count = n;
				avg_count = n;
				best_count = n;

				// Output to the file the required data

				compsout << fixed << setprecision(3) << n << '\t' << worst_count << '\t' << avg_count << '\t' << best_count << '\t' << bubblesort(dsc_copy, n) << '\t' << bubblesort(rnd_copy, n);
				if (n != 4000) { compsout << '\t' << '-'; }
				else { compsout << '\t' << bubblesort(asc_copy, n); }
				compsout << endl;
			}
			compsout << '\n' << endl;
			break;

		case 5: // Insertion Sort
			compsout << "\t --- Insertion Sort ---" << endl;
			for (int n = 1000; n <= 4000; (n += 1000)) {
				// Declare and initialize three arrays that will be local copies of each specific dataset
				int rnd_copy[4000];
				int dsc_copy[4000];
				int asc_copy[4000];
				for (int j = 0; j < n; ++j) {
					rnd_copy[j] = rnd[j];
					dsc_copy[j] = dsc[j];
					asc_copy[j] = asc[j];
				}

				// Calculate worst, avg, and best case # of comparisons based on size
				// Average case is O(n^2) comparisons
				// Worst case is O(n^2)
				// Best case would be when everything is already sorted, O(n) comparisons
				worst_count = pow(n, 2.0);
				avg_count = worst_count;
				best_count = n;

				// Output to the file the required data

				compsout << fixed << setprecision(3) << n << '\t' << worst_count << '\t' << avg_count << '\t' << best_count << '\t' << insertionsort(dsc_copy, n) << '\t' << insertionsort(rnd_copy, n);
				if (n != 4000) { compsout << '\t' << '-'; }
				else { compsout << '\t' << insertionsort(asc_copy, n); }
				compsout << endl;
			}
			compsout << '\n' << endl;
			break;

		}

	}


	compsout.close(); // Close output filestream

	return 0;
}
