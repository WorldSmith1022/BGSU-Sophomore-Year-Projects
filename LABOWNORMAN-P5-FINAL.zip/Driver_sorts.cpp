// Created by Norman Labow
// Project 5 - Due 11/9/2022
// Driver to print the sorted output from each algorithm 
// for JUST the three 8,000 element data sets (with no data
// comparison output) into a file

#include <iostream>
#include <fstream>
#include "number_data.h"
#include "quick.h"
#include "select.h"
#include "merge.h"
#include "heapsort.h"
#include "insertion.h"
#include "bubble.h"

using namespace std;

/*
int main() {

	// Create output filestreams
	ofstream sortsout;
	// Open file, check to ensure it opens
	sortsout.open("sortsout.txt");
	if (!sortsout.is_open()) {
		cout << "Could not open sortsout.txt. Ending program." << endl;
		return 1;
	}

	// Due to stack overflow exceptions, I went with significantly lower size limits.
	// First, create input data sets of sizes 100, 200, 400, and 800 for the following:
	// a. Random Data
	// b. Reverse (descending) sorted data
	// c. 8000 elements of (ascending) sorted data

	// Declare all three arrays of size 800 (made smaller to avoid stack overflow)
	int rnd[4000];
	int dsc[4000];
	int asc[4000];

	// Initialize the arrays
	fill_random_numbers(rnd, 4000);
	fill_sorted_numbers(asc, dsc, 4000);

	// Use a for loop and switch statement to go through each data set
	for (int i = 0; i < 3; ++i) {

		// This data set will be a copy of the unsorted data sets, in which it will be sorted
		int dataset[4000];

		// Use a switch statement to state which data set is being sorted
		switch (i) {		
		case 0:
			sortsout << "\t\t --- RANDOM NUMBERS ---" << endl;
			break;
		case 1:
			sortsout << "\t\t --- DESCENDING ORDER ---" << endl;
			break;
		case 2: 
			sortsout << "\t\t --- ASCENDING ORDER ---" << endl;
			break;
		}

		// Use an inner for loop and switch statement to go through each sorting algorithm
		for (int j = 0; j < 6; ++j) {

			// Use a switch statement to set dataset to one of the data sets to be sorted
			switch (i) {
			case 0: // Copy the random dataset
				for (int j = 0; j < 4000; ++j) { dataset[j] = rnd[j]; }
				break;

			case 1: // Copy the descending order dataset
				for (int j = 0; j < 4000; ++j) { dataset[j] = dsc[j]; }
				break;

			case 2: // Copy the ascending order dataset
				for (int j = 0; j < 4000; ++j) { dataset[j] = asc[j]; }
				break;
			}

			// Use a switch statement to determine which sorting algorithm to use
			switch (j) {
			case 0: // Quicksort 
				quicksort(dataset, 4000); // Sort the algorithm
				sortsout << "\t --- Quicksort ---" << endl;
				for (unsigned int k = 0; k < 4000; ++k) { sortsout << dataset[k] << "  "; } // Output each entry w/ a for loop
				sortsout << '\n' << endl;
				break;

			case 1: // Selection Sort
				selectionsort(dataset, 4000); // Sort the algorithm
				sortsout << "\t --- Selection Sort ---" << endl;
				for (unsigned int k = 0; k < 4000; ++k) { sortsout << dataset[k] << "  "; } // Output each entry w/ a for loop
				sortsout << '\n' << endl;
				break;

			case 2: // Merge Sort
				mergesort(dataset, 4000); // Sort the algorithm
				sortsout << "\t --- Merge Sort ---" << endl;
				for (unsigned int k = 0; k < 4000; ++k) { sortsout << dataset[k] << "  "; } // Output each entry w/ a for loop
				sortsout << '\n' << endl;
				break;

			case 3: // Heapsort
				heapsort(dataset, 4000); // Sort the algorithm
				sortsout << "\t --- Heapsort ---" << endl;
				for (unsigned int k = 0; k < 4000; ++k) { sortsout << dataset[k] << "  "; } // Output each entry w/ a for loop
				sortsout << '\n' << endl;
				break;

			case 4: // Bubble Sort
				bubblesort(dataset, 4000); // Sort the algorithm
				sortsout << "\t --- Bubble Sort ---" << endl;
				for (unsigned int k = 0; k < 4000; ++k) { sortsout << dataset[k] << "  "; } // Output each entry w/ a for loop
				sortsout << '\n' << endl;
				break;

			case 5: // Insertion Sort
				insertionsort(dataset, 4000); // Sort the algorithm
				sortsout << "\t --- Insertion Sort ---" << endl;
				for (unsigned int k = 0; k < 4000; ++k) { sortsout << dataset[k] << "  "; } // Output each entry w/ a for loop
				sortsout << '\n' << endl;
				break;

			}

		}

		sortsout << '\n' << endl;
	}

	sortsout.close(); // Close output filestream

	return 0;
}
*/
