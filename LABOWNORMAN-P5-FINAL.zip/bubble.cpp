// FILE: bubble.cpp
// An interactive test program for the insertionsort function
#include <algorithm>  // Provides swap
#include <cstdlib>    // Provides EXIT_SUCCESS, size_t
#include <iostream>   // Provides cout and cin
#include "bubble.h"
using namespace std;

// Algorithm taken from Zybooks Fig. 13.1.1
int bubblesort(int data[], size_t n) {
    int count = 0; // # of comparisons

    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (data[j] > data[j + 1]) {
                ++count;
                swap(data[j], data[j + 1]);
            }
        }
    }

    return count;
}