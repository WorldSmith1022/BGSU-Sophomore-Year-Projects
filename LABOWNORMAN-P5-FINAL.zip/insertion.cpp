// FILE: insertion.cpp
// An interactive test program for the insertionsort function
#include <algorithm>  // Provides swap
#include <cstdlib>    // Provides EXIT_SUCCESS, size_t
#include <iostream>   // Provides cout and cin
#include "insertion.h"
using namespace std;

// Algorithm taken from Zybooks Fig. 3.3.1
int insertionsort(int data[], size_t n) {
	int count = 0; // # of comparisons
    int i = 0;
    int j = 0;
    for (i = 1; i < n; ++i) {
        j = i;
        // Insert numbers[i] into sorted part
        // stopping once numbers[i] in correct position
        while (j > 0 && data[j] < data[j - 1]) {
            ++count;
            // Swap numbers[j] and numbers[j - 1]
            swap(data[j], data[j - 1]);
            --j;
        }
    }

	return count;
}