// FILE: select.cpp
// An interactive test program for the selectionsort function

#include <algorithm>  // Provides swap
#include <cstdlib>    // Provides EXIT_SUCCESS, size_t
#include <iostream>   // Provides cout and cin
#include "select.h"
using namespace std;

int selectionsort(int data[ ], size_t n)
// Library facilities used: algorithm, cstdlib
{
    int count = 0; // # of comparisons
    size_t i, j, index_of_largest;
    int largest;

    if (n == 0)
        return count; // No work for an empty array.
        
    for (i = n-1; i > 0; --i)
    {
        largest = data[0];
        index_of_largest = 0;
        for (j = 1; j <= i; ++j)
        {
            if (data[j] > largest)
            {
                largest = data[j];
                index_of_largest = j;
            }
            ++count; // Comparison has been made; Increment count
        }
        swap(data[i], data[index_of_largest]);
    }

    return count;
}
