/*	Creator: Norman Labow
*	Due Date: 9/7/2022
*	This C program is a rewritten version of randNumA.
*	1. It will take 4+1 arguments for its main function.
*	2. It will make those arguments into usable integers when necessary and prepare for random number generation. 
*	3. Generate random numbers based on user arguments and write them into a text file. 
*	4. It will read the numbers in the text file and print them out for the user to see. 
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main(int argc, char* argv[]) {
	/*	Objective 1: Check to ensure 4 + 1 arguments were passed when this program was called
	*	If the correct number of arguments were passes, declare and initialize all necessary variables. 
	*/

	/*	If not enough arguments are passed, end the program. */
	if (argc != 5) {
		printf("ERROR: Invalid number of arguments! Ending Program.");
		return 1;
	}

	/*	Now, declare all variables.
	*	Name of data file. Instead of a string like in our C++ file, this is a C-String (char array).
	*	# of integers to randomly generate
	*	Range of the numbers that can be generated (i.e. 1-1000)
	*	Seed for random number generation
	*	Variable containing randomly generated integer value
	*	Loop operator integer, i
	*/

	char dataFileName[14];
	int numItems;
	int range;
	int seed;
	int currNum;
	int i;


	/* Objective 2: Upon getting the correct # of arguments, convert all numbers(from arguments) to integers using atoi.
	* These will be stored in these variables.
	*/

	strcpy(dataFileName, argv[1]);
	numItems = atoi(argv[2]);
	range = atoi(argv[3]);
	seed = atoi(argv[4]);

	/* Use the seed for random number generation */
	srand(seed);

	/* Prepare to write (in append mode) to a text file, datafileB.txt. */
	FILE *outstream = fopen(dataFileName, "a");
	if (outstream == NULL) {
		printf("The data file could not be opened for output. Ending Program.");
		fclose(outstream);
		return 1;
	}

	/*	Objective 3: Generate[numItems] random integers and write them in the output text file. */
	currNum = 0;
	for (i = 0; i < numItems; ++i) {
		/*	Generate a new random integer. */
		currNum = ((rand() % range) + 1);
		/*	Print the random integer in the text file. Each integer is separated by a newline character for easier reading later. */
		fprintf(outstream, "%-4d", currNum);
	}
	fclose(outstream);

	/*	Objective 4: Read through the output file, and print all numbers within it.
	*	Numbers should be formatted so each line has 5 numbers separated by tabs.
	*/
	/*	Prepare to read from the text file, datafileB.txt. */
	FILE *instream = fopen(dataFileName, "r");
	if (instream == NULL) {
		printf("The data file could not be opened for reading. Ending Program.");
		fclose(instream);
		return 1;
	}
	
	/*	Read numbers from the text file until it reaches the end of the file, returning NULL. 
		currptr is set to NULL before the loop begins in case the file is empty. */
	char *currptr = NULL;
	char str[5];
	/*	This while loop will continue until the end of the file is reached */
	do {
		/*	This for loop starts a new line every 5 integers printed */
		for (i = 0; i < 5; ++i) { 
			/*	Get input from the file, store it within str and have currptr point to it */
			currptr = (fgets(str, 5, instream));
			/*	If currptr is pointing to something, print the result. */
			if (currptr != NULL) {
				printf("%s ", currptr);
			}
		}
		/*	After 5 numbers have been printed, print a newline character. (As long as currptr isn't NULL.) */
		if (currptr != NULL) { printf("\n"); }
	} while (currptr != NULL);

	return 0;
}