/* Creator: Norman Labow
* Due Date: 9/7/2022
* This C++ program will do 4 things: 
* 1. Take in 4+1 arguments for the main function, and check to ensure it received the correct number of arguments
* 2. Turn the char array arguments into strings and integers where necessary and prepare the program for random number generation as 
*		well as file output.
* 3. Generate random integers based on the values passed as arguments and write them to datafileA.txt
* 4. Read in the numbers from datafileA.txt and print them out to the console with proper formatting
*/
#include <iostream>
#include <fstream>
using namespace std;

int main(int argc, char *argv[]) {

	// Objective 1: Check to ensure 4+1 arguments were passed when this program was called

	// The code below lists out how many arguments are called and lists off each one. This will probably be commented out in the final version.
	/*
	cout << argc << " arguments were called: " << endl;
	for (int i = 0; i < argc; ++i) {
		cout << i << ".   " << argv[i] << endl;
	}
	*/

	// If not enough arguments are passed, end the program.
	if (argc != 5) {
		cout << "ERROR: Invalid number of arguments! Ending Program." << endl;
		return 1;
	}

	// Objective 2: Upon getting the correct # of arguments, convert all numbers (from arguments) to integers using atoi.
	// These will be stored in these variables.
	string dataFileName = argv[1]; // Name of data file
	int numItems = atoi(argv[2]); // # of integers to randomly generate
	int range = atoi(argv[3]); // Range of the numbers that can be generated (i.e. 1-1000)
	int seed = atoi(argv[4]); // Seed for random number generation

	srand(seed); // Use the seed for random number generation

	ofstream outFS; // Output filestream

	// Attempt to open output file. If it cannot be opened, end the program.
	outFS.open(dataFileName);
	if (!outFS.is_open()) {
		cout << "ERROR: " << dataFileName << " could not be opened for output! Ending Program." << endl;
		return 1;
	}


	// Objective 3: Generate [numItems] random integers and write them in the output text file.
	int numGen = 0;
	for (int i = 0; i < numItems; ++i) {
		numGen = ((rand() % range) + 1); // Generate new int and store its value in numGen
		// Output number to file, separated by a space (except for the final number)
		outFS << numGen;
		if (i < (numItems - 1)) { 
			outFS << ' ';
		}
	}
	outFS.close(); // Close output file

	// Objective 4: Read through the output file, and print all numbers within it.
	// Numbers should be formatted so each line has 5 numbers separated by tabs.
	ifstream inFS; // Input filestream
	inFS.open(dataFileName);
	if (!inFS.is_open()) {
		cout << "ERROR: " << dataFileName << " could not be opened for input! Ending Program." << endl;
		return 1;
	}
	int currNum;
	while (!inFS.fail() && !inFS.eof()) { // Read and print every number until the end of the data file is reached (or if something goes wrong)
		currNum = 0;
		for (int i = 0; i < 5; ++i) { // This for loop separates the numbers into 5 per line
			inFS >> currNum;
			cout << currNum << '\t';
		}
		cout << endl;
	}

	// Check to ensure that the end of the file was reached.
	if (!inFS.eof()) {
		cout << "ERROR: inFS did not reach the end of the file! Ending Program." << endl;
		inFS.close();
		return 1;
	}

	inFS.close(); // Close input filestream

	// Celebrate a successful run of the program (commented out in final version)
	// cout << "Program reached the end successfully! Yippee!" << endl;
	return 0;
}