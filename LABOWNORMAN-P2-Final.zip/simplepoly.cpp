#include <cassert>
#include <iostream>
#include <cmath> // I am including this for the pow() function
#include "simplepoly.h"

using namespace std;

const unsigned int SimplePoly::SIZEINCR = 5;
// SIZEINCR is the size increment used in expanding
// the dynamic arrays as needed.

SimplePoly::SimplePoly()
{
// Pre: None.
// Post: A basic "zero" polynomial object is created
// with zero terms.  Variable is assumed to be x.

	variable = 'x';
	LargestExp = -1;
	terms = new term[CAPACITY = SIZEINCR];
};

void SimplePoly::copy (const SimplePoly & p)
{
	// Pre: p is a valid polynomial.
	// Post: p is DEEP-COPIED into the implicit parameter.
	
// *DO: FILL IN WITH AN APPROPRIATE IMPLEMENTATION
	// Copy the character value for the variable. Get the capacity and Largest Exp. using
	// similar code to the expand() function.
	variable = p.variable;
	LargestExp = p.LargestExp;
	CAPACITY = (LargestExp / SIZEINCR + 1) * SIZEINCR;
	terms = new term[CAPACITY];
	for (int i = 0; i <= LargestExp; i++) {
		this->terms[i].coeff = p.terms[i].coeff;
	}
};

SimplePoly::SimplePoly (const SimplePoly & p) //DEEP COPY SEMANTICS
{
	// Pre: p is a valid polynomial.
	// Post: p is copied into the implicit parameter
	// using "deep copy semantics."

	copy (p);
};

void SimplePoly::free (void)
{
	// Pre: The implicit parameter has been allocated.
	// Post: Any necessary deallocation is done.

// *DO: FILL IN WITH AN APPROPRIATE IMPLEMENTATION
	delete[] terms;
	terms = nullptr;
};

SimplePoly::~SimplePoly (void)
{
	// Pre: The implicit parameter has been allocated.
	// Post: Any necessary deallocation is done.

	free ();
};

SimplePoly & SimplePoly::operator= (const SimplePoly & p) //DEEP COPY SEMANTICS
{
	// Pre: p is a valid polynomial.
	// Post: The value of p is assigned to the implicit parameter
	// by "deep copy semantics."  Any necessary deallocation is
	// done along the way.

	if (this != &p)
	{
		free ();
		copy (p);
	};
	return (*this);
};

void SimplePoly::expand (unsigned int LargeExp)
{
	// Pre: Implicit parameter is a valid polynomial.  LargeExp is
	// a new exponent that needs to be accommpdated through expansion.
	// post: The size of the polynomial store in the implicit
	// parameter is expanded to the lowest multiple of SIZEINCR that
	// can accommodate a term with the LargeExp, while keeping the
	// polynomial value the same.

	termptr p;

	CAPACITY = (LargeExp / SIZEINCR + 1) * SIZEINCR;
	p = new term[CAPACITY];
	for (int j=0; j<=LargestExp; j++) p[j] = terms[j];
	delete [] terms;
	terms = p;
};

void SimplePoly::InsertTerm (int coef, int exp)
{
	// Pre: Implicit parameter is a valid polynomial NOT
	// containing any term with the same exponent as exp.
	// Post: A new term corresponding to the given coefficient coef
	// and exponent exp is inserted into the implicit parameter polynomial.
	// In the process, the polynomial is "expanded" if necessary.

	if (coef)
	{
		assert((exp >= CAPACITY) || (terms[exp].coeff == 0));
		// There is no term with the same exponent and a non-zero coefficient
		// already present.

		if (exp >= CAPACITY) expand(exp);

		terms[exp].coeff = coef;
		if ((coef != 0) && (exp > LargestExp)) LargestExp = exp;
	}
};

void SimplePoly::read ()
{
	// Pre: None.
	// Post: A new value is read into the implicit paramter polynomial, per
	// instructions as given out first.  If needed, the old value is destroyed.

	SimplePoly temp;
	int coeff;
	int exp;
	cout << "Input a polynomial by specifying the variable and all terms in any order." << endl
		<< "Each term is specified by an integer coefficient and" << endl
		<< "a non-negative integer exponent." << endl
		<< "Indicate END by specifying a dummy term with" << endl
		<< "a zero coefficient and/or a negative exponent." << endl;
	cin >> temp.variable;
	do
	{
		cin >> coeff;
		if (coeff)
		{
			cin >> exp;
			if (exp >= 0)
				temp.InsertTerm (coeff, exp);
		}
		else
			while (cin && (cin.peek() != '\n')) cin. ignore();
	} while (coeff && (exp >= 0));
	*this = temp; // The assignment operator is being called here!
};


//	This isn't really a question or anything, but just a thought I had. Why do we write
//	exponents being flush with the coefficient and variable like "3x2" when we could instead 
//	write it as "3x^2"? Maybe I should ask in class. 
void SimplePoly::write() const
{
	// Pre: The implicit parameter (this) is a valid polynomial (possibly zero).
	// Post: The polynomial represented by the implicit parameter (this) is
	// printed out on the standard output.  The variable is used as stored.
	
// *DO: FILL IN WITH AN APPROPRIATE IMPLEMENTATION

	// Ensure that there are terms within the polynomial to begin with
	if (LargestExp >= 0) {

		// Continue this loop until there are no more terms in the polynomial
		for (int exp = LargestExp; exp >= 0; --exp) {

			// Terms with a coefficient of 0 do not need to be printed. 
			if (terms[exp].coeff != 0) {

				// Print out the sign of the term. If this is the first term, only print out the sign if it is negative.
				// Since the negative sign is automatically printed if the coefficient is below 0, we only need to worry about
				// printing the sign if the coefficient is positive. That way, we don't accidentally print "--4x3" or something.
				if (exp != LargestExp && terms[exp].coeff > 0) {
					cout << terms[exp].sign();
				}

				// Print the coefficient
				cout << terms[exp].coeff;

				// If the exponent is 1, do not print the exponent. If it is 0, do not print the variable or exponent.
				if (exp > 0) {
					if (exp == 1) { cout << variable; }
					else { cout << variable << exp; }
				}
				// Print out a space between each term
				cout << ' ';
			}

		}

	}
	// If there are no terms in the polynomial (or if it simply hasn't been created yet), print out 0.
	else {
		cout << "0";
	}

	cout << endl;
};


SimplePoly SimplePoly::plus (const SimplePoly & right) const
{
	// Pre: The implicit parameter and the parameter right are valid
	// polynomials.
	// Post: The sum of the two parameters is returned by plus.

// *DO: FILL IN WITH AN APPROPRIATE IMPLEMENTATION

	// Using a for loop, I would need to add together the coefficients of like terms (same coefficient)

	// Create a new polynomial of the sum by first copying the right-side polynomial
	SimplePoly sum;
	int sumCoeff; // Sum of two coefficients

	// Depending on which polynomial has a higher largest exponent, create a for loop to add each set of terms to sum.
	// If the left polynomial is larger
	if (CAPACITY >= right.CAPACITY) {

		// Copy over the variable character of the left polynomial
		sum.variable = variable;

		// This for loop will go on until the end of the left polynomial is reached.
		for (int currExp = 0; currExp < CAPACITY; ++currExp) {
			// This if statement will ensure that there won't be an access violation once currExp goes
			// beyond the right polynomial's largest exponent
			if (currExp <= right.LargestExp) {
				// Add the coefficients of the two like terms together.
				sumCoeff = (terms[currExp].coeff + right.terms[currExp].coeff);
			}
			else {
				// Once currExp goes beyond the largest exponent of the right polynomial, there should be no more terms 
				// to add together. With that, sumCoeff would just be the same as the left handed polynomial.
				sumCoeff = terms[currExp].coeff;
			}

			// Now that we have a coefficient and an exponent, it is now time to insert a new term into sum.
			// If the sumCoeff is still equal to 0, do not add this term.
			if (sumCoeff != 0) {
				sum.InsertTerm(sumCoeff, currExp);
			}
		}
	}
	// If the right polynomial is larger
	else {

		// Copy over the variable character of the right polynomial
		sum.variable = right.variable;

		// This for loop will go on until the end of the right polynomial is reached.
		for (int currExp = 0; currExp < right.CAPACITY; ++currExp) {
			// This if statement will ensure that there won't be an access violation once currExp goes
			// beyond the left polynomial's largest exponent
			if (currExp <= LargestExp) {
				// Add the coefficients of the two like terms together.
				sumCoeff = (right.terms[currExp].coeff + terms[currExp].coeff);
			}
			else {
				// Once currExp goes beyond the largest exponent of the left polynomial, there should be no more terms 
				// to add together. With that, sumCoeff would just be the same as the right handed polynomial.
				sumCoeff = right.terms[currExp].coeff;
			}

			// Now that we have a coefficient and an exponent, it is now time to insert a new term into sum.
			if (sumCoeff != 0) {
				sum.InsertTerm(sumCoeff, currExp);
			}
		}
	}

	return sum; // Return the result
};


SimplePoly SimplePoly::minus (const SimplePoly & right) const
{
	// Pre: The implicit parameter and the parameter right are valid
	// ploynomials.
	// Post: The difference of the two parameters is returned by minus.
	// The polynomial right is subtracted from the implicit parameter.
	
// *DO: FILL IN WITH AN APPROPRIATE IMPLEMENTATION
	// Using a for loop, I would need to subtract the coefficients of like terms (same coefficient)

	// Create a new polynomial of the sum by first copying the right-side polynomial
	SimplePoly result;
	int resultCoeff; // Sum of two coefficients

	// Depending on which polynomial has a higher largest exponent, create a for loop to add each set of terms to sum.
	// If the left polynomial is larger
	if (CAPACITY >= right.CAPACITY) {

		// Copy over the variable character of the left polynomial
		result.variable = variable;

		// This for loop will go on until the end of the left polynomial is reached.
		for (int currExp = 0; currExp < CAPACITY; ++currExp) {
			// This if statement will ensure that there won't be an access violation once currExp goes
			// beyond the right polynomial's largest exponent
			if (currExp <= right.LargestExp) {
				// Subtract the right term's coefficient from the left term
				resultCoeff = (terms[currExp].coeff - right.terms[currExp].coeff);
			}
			else {
				// Once currExp goes beyond the largest exponent of the right polynomial, there should be no more terms 
				// to subtract. With that, sumCoeff would just be the same as the left handed polynomial.
				resultCoeff = terms[currExp].coeff;
			}

			// Now that we have a coefficient and an exponent, it is now time to insert a new term into resulting polynomial.
			// If the resultCoeff is equal to 0, do not insert this term.
			if (resultCoeff != 0) {
				result.InsertTerm(resultCoeff, currExp);
			}
		}
	}
	// If the right polynomial is larger
	else {

		// Copy over the variable character of the right polynomial
		result.variable = right.variable;

		// This for loop will go on until the end of the right polynomial is reached.
		for (int currExp = 0; currExp < right.CAPACITY; ++currExp) {
			// This if statement will ensure that there won't be an access violation once currExp goes
			// beyond the left polynomial's largest exponent
			if (currExp <= LargestExp) {
				// Subtract the right term's coefficient from the left term
				resultCoeff = (terms[currExp].coeff - right.terms[currExp].coeff);
			}
			else {
				// Once currExp goes beyond the largest exponent of the left polynomial, there should be no more terms 
				// on the left side to subtract from. With that, sumCoeff would just be 0 minus the right side coefficient.
				resultCoeff = (0 - right.terms[currExp].coeff);
			}

			// Now that we have a coefficient and an exponent, it is now time to insert a new term into sum.
			if (resultCoeff != 0) {
				result.InsertTerm(resultCoeff, currExp);
			}
		}
	}

	return result; // Return the result// Using a for loop, I would need to add together the coefficients of like terms (same coefficient)

	// Create a new polynomial of the sum by first copying the right-side polynomial
	SimplePoly sum;
	int sumCoeff; // Sum of two coefficients

	// Depending on which polynomial has a higher largest exponent, create a for loop to add each set of terms to sum.
	// If the left polynomial is larger
	if (CAPACITY >= right.CAPACITY) {

		// Copy over the variable character of the left polynomial
		sum.variable = variable;

		// This for loop will go on until the end of the left polynomial is reached.
		for (int currExp = 0; currExp < CAPACITY; ++currExp) {
			// This if statement will ensure that there won't be an access violation once currExp goes
			// beyond the right polynomial's largest exponent
			if (currExp <= right.LargestExp) {
				// Add the coefficients of the two like terms together.
				sumCoeff = (terms[currExp].coeff + right.terms[currExp].coeff);
			}
			else {
				// Once currExp goes beyond the largest exponent of the right polynomial, there should be no more terms 
				// to add together. With that, sumCoeff would just be the same as the left handed polynomial.
				sumCoeff = terms[currExp].coeff;
			}

			// Now that we have a coefficient and an exponent, it is now time to insert a new term into sum.
			// If the sumCoeff is still equal to 0, do not add this term.
			if (sumCoeff != 0) {
				sum.InsertTerm(sumCoeff, currExp);
			}
		}
	}
	// If the right polynomial is larger
	else {

		// Copy over the variable character of the right polynomial
		sum.variable = right.variable;

		// This for loop will go on until the end of the right polynomial is reached.
		for (int currExp = 0; currExp < right.CAPACITY; ++currExp) {
			// This if statement will ensure that there won't be an access violation once currExp goes
			// beyond the left polynomial's largest exponent
			if (currExp <= LargestExp) {
				// Add the coefficients of the two like terms together.
				sumCoeff = (right.terms[currExp].coeff + terms[currExp].coeff);
			}
			else {
				// Once currExp goes beyond the largest exponent of the left polynomial, there should be no more terms 
				// to add together. With that, sumCoeff would just be the same as the right handed polynomial.
				sumCoeff = right.terms[currExp].coeff;
			}

			// Now that we have a coefficient and an exponent, it is now time to insert a new term into sum.
			if (sumCoeff != 0) {
				sum.InsertTerm(sumCoeff, currExp);
			}
		}
	}

	return sum; // Return the result
};


float SimplePoly::evaluate (float value) const
{
	// Pre: The implicit parameter is a valid polynomial.
	// Post: The value of the polynomial with the value substituted for the variable is returned.

// *DO: FILL IN WITH AN APPROPRIATE IMPLEMENTATION
	// Using a for loop, evaluate each term of the polynomial if variable x is equal to value.

	float result = 0.0;
	float termValue;
	int exp;

	// Going downwards, work through every exponent value until the exponent is equal to 0. 
	for (exp = LargestExp; exp > 0; --exp) {
		// Reset the value of termValue
		termValue = 0.0;

		// No need to bother with terms with coefficients of 0; they are not included in these polynomials.
		if (terms[exp].coeff != 0) {

			// First, find out what the value to the 'exp' power is equal to using the pow() function.
			termValue = pow(value, exp);
			// Then, multiply by the coefficient
			termValue *= terms[exp].coeff;
			// Finally, add the value of the term to the total result
			result += termValue;
		}
	}

	// Once the for loop is finished, add the term to the 0th exponent to the result (nothing changes if it is equal to 0)
	result += terms[0].coeff;

	// Return the result
	return result;
};


// I created this accessor function so that simplepolydr can access a SimplePoly object's variable value.
char SimplePoly::getVariable() {
	return variable;
}
