// Author: Norman Labow
// CS 3080 Project 3
// Due 10/20/22
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>

// Global Definitions

#define NUM_THREADS 2 // Number of threads is 2

#define S 10 // Buffer size S=10
#define NUM_ITEMS 10 // Number of items to produce/consume

// Global Variables
int buf[S];	
int minimum = 1001;
int  maximum = 0; // Min/max variables
float sum, avg = 0.0; // Sum/Avg variables
pthread_t thread[NUM_THREADS]; // Array of threads

using namespace std;

// Producer Function
void *produce(void *t) {
	// printf("P - PRODUCER FUNCTION BEGIN\n");

	// Declare Random Number
	int n;
	// Declare thread id
	long tid = (long)t;

	// Loop for 10 items
	for (int i = 0; i < NUM_ITEMS; ++i) {
		// Generate a random number between 1-1000
		n = ((rand() % 1000) + 1);
		// Add the random number into the buffer
		buf[i] = n;
		// printf("P -  WROTE %d INTO BUF[%d]\n", n, i);
	}
	// printf("P - PRODUCER FUNCTION END, EXITING THREAD.\n");
	pthread_exit(0);
}

// Conumer Function
void *consume(void *t) {
	// printf("C - CONSUMER FUNCTION BEGIN\n");

	// Declare number to be retrieved from the buffer
	int n;
	// Declare thread id
	long tid = (long)t;

	// Loop 10 items
	for (int i = 0; i < NUM_ITEMS; ++i) {
		
		// Busy loop to slow down consumer
		long y;
		int x = 5;
		for (long j = 0; j < 1000000; ++j) {
			y = x * j;
		}

		// Get number from the buffer
		n = buf[i];

		// To do something in order to make the consumer function wait up,
		// Check to see if n is the min or max, and update the avg

		// Check for min/max
		if (n < minimum) { minimum = n; }
		if (n > maximum) { maximum = n; }

		// Update the sum
		sum += n;
	}
	// Update the avg
	avg = sum / NUM_ITEMS;

	// printf("! - CONSUMER FUNCTION END, EXITING THREAD.\n");
	pthread_exit(0);
}

// Main Function
int main() {
	// Confirm Project has begun
	// printf("! - MAIN FUNCTION BEGIN \n");

	// Initialize Thread Attributes
	pthread_attr_t a;
	pthread_attr_init(&a);
	pthread_attr_setdetachstate(&a, PTHREAD_CREATE_JOINABLE);
	
	long t;

	for (t = 0; t < NUM_THREADS; ++t) {
		if (t == 0) {
			pthread_create(&thread[t], &a, produce, (void *)t);
		}
		else {
			pthread_create(&thread[t], &a, consume, (void *)t);
		}
	}

	// Use myID as the seed for RNG
	// Return calling thread's ID (should be that of the parent, main)
	pthread_t myID = pthread_self();
	srand(myID);

	// Free the attributes so that the threads can be joined
	pthread_attr_destroy(&a);

	// Join the threads
	for (t = 0; t < NUM_THREADS; ++t) {
		pthread_join(thread[t], 0);
	}

	// Report the min, max, and avg
	printf("Min: %d\n", minimum);
	printf("Max: %d\n", maximum);
	printf("Average: %5.2f\n", avg);

	// printf("! - END OF MAIN.\n");

	return 0;
}
