// Author: Norman Labow
// Due: 9/29/2022

#include <sys/types.h>
#include <iostream>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>

#define READ_END	0
#define WRITE_END	1

int buf; /* Buffer for passing info via the pipe */
#define BUFFER_SIZE	sizeof(buf)

using namespace std;

int main(int argc, char *argv[]) {
	/* Main begin */
	int num;
	int fd[2];

	/* Take in arguments from main() */
	/*	If not enough arguments are passed, end the program. */
	if (argc != 4) {
		fprintf(stderr, "ERROR: Invalid number of arguments! Ending Program.");
		exit(-1);
	}

	/* Variables for arguments passed to main() */
	int numItems;
	int range;
	int seed;
	numItems = atoi(argv[1]);
	range = atoi(argv[2]);
	seed = atoi(argv[3]);

	/* Use seed for random number generation */
	srand(seed);

	/* Create pipe */
	pid_t pid;
	if (pipe(fd) == -1) {
		fprintf(stderr, "Pipe failed");
		exit(-1);
	}

	/* Create fork */
	pid = fork();
	if (pid < 0) {
		fprintf(stderr, "Fork failed");
		return 1;
	}

	int min = 1000;
	int max, sum = 0;
	float avg = 0.0;
	int numItemsWritten, numItemsReceived = 0;

	/* Child will read in the int from the pipe and update the min/max/avg */
	if (pid == 0) {
		close(fd[WRITE_END]);
		for (int i = 0; i < numItems; ++i) { 
			read(fd[READ_END], &buf, sizeof(buf));
			++numItemsReceived;
			if (buf < min) {
				min = buf;
			}
			if (buf > max) {
				max = buf;
			}
			sum += buf;
			avg = (sum / (i + 1));
		}
		close(fd[READ_END]);
		printf("Child ID: %d, number items received: %d, min: %d, max: %d, avg: %f \n", pid, numItemsReceived, min, max, avg);
	}

	/* Parent will generate a random int and write it to the pipeline */
	else if (pid > 0) {
		close(fd[READ_END]);
		for (int i = 0; i < numItems; ++i) {
			num = rand() % range;
			buf = num;
			write(fd[WRITE_END], &buf, BUFFER_SIZE);
			++numItemsWritten;
		}
		close(fd[WRITE_END]);
		/* Parent will wait for child to finish, then it will print out info */
		wait(0);
		printf("Parent ID: %d, number items written into the pipes are: %d\n", pid, numItemsWritten);
	}

	// Main end
	return 0;
}
