// FILE: bintreetemplate.h
// IMPLEMENTS: The nine template functions of the second version of the binary
// tree toolkit (see bintree.h for documentation). Note that this file is not
// compiled on its own. Instead, this file is included by an include directive
// at the bottom of bintree.h.

#include <cassert>    // Provides assert
#include <iomanip>   // Provides setw
#include <iostream>  // Provides cout
#include <cstdlib>    // Provides NULL, size_t


using namespace std;

// Programming note: Some compilers require that the default argument is
// listed in the implementation as well as the prototype, so we have
// include the default arguments for create_node.
template <class Item>
BinaryTreeNode<Item>* create_node(
    const Item& entry,
    BinaryTreeNode<Item>* l_ptr,
    BinaryTreeNode<Item>* r_ptr
)
{
    BinaryTreeNode<Item>* result_ptr;

    result_ptr = new BinaryTreeNode<Item>;
    result_ptr->data  = entry;
    result_ptr->left  = l_ptr;
    result_ptr->right = r_ptr;

    return result_ptr;
}

template <class Item>
BinaryTreeNode<Item>* tree_copy(const BinaryTreeNode<Item>* root_ptr)
// Library facilities used: stdlib.h
{
    BinaryTreeNode<Item> *l_ptr;
    BinaryTreeNode<Item> *r_ptr;

    if (root_ptr == NULL)
        return NULL;
    else
    {
        l_ptr = tree_copy(root_ptr->left);
        r_ptr = tree_copy(root_ptr->right);
        return create_node(root_ptr->data, l_ptr, r_ptr);
    }
}

template <class Item>
void tree_clear(BinaryTreeNode<Item>*& root_ptr)
{
    if (root_ptr != NULL)
    {
        tree_clear(root_ptr->left);
        tree_clear(root_ptr->right);
        delete root_ptr;
        root_ptr = NULL;
    }
}

template <class Item>
bool is_leaf(const BinaryTreeNode<Item>& node)
{
    return (node.left == NULL) && (node.right == NULL);
}

template <class Process, class Item>
void inorder(Process f, BinaryTreeNode<Item>* node_ptr)
{
    if (node_ptr != NULL)
    {
        inorder(f, node_ptr->left);
        f(node_ptr->data);
        inorder(f, node_ptr->right);
    }
}

template <class Process, class Item>
void postorder(Process f, BinaryTreeNode<Item>* node_ptr)
{
    if (node_ptr != NULL)
    {
        postorder(f, node_ptr->left);
        postorder(f, node_ptr->right);
        f(node_ptr->data);
    }
}

template <class Process, class Item>
void preorder(Process f, BinaryTreeNode<Item>* node_ptr)
{
    if (node_ptr != NULL)
    {
        f(node_ptr->data);
        preorder(f, node_ptr->left);
        preorder(f, node_ptr->right);
    }
}

template <class Item>
size_t tree_size(const BinaryTreeNode<Item>* node_ptr)
// Library facilities used: stdlib.h
{
    if (node_ptr == NULL)
        return 0;
    else
        return 1 + tree_size(node_ptr->left) + tree_size(node_ptr->right);
}

//
//   template <class Item, class SizeType>
//   void printTreeAtDepth (BinaryTreeNode<Item>* node_ptr, SizeType depth)
//     Precondition: node_ptr is a pointer to a node in a binary
//     tree (or node_ptr may be NULL to indicate the empty tree).
//     If the pointer is NULL, then depth is expected to be 0.
//     If the pointer is not NULL, then depth is the depth of
//     the node pointed to by node_ptr.
//     Postcondition: If node_ptr is non-NULL, then the contents
//     of *node_ptr and all its descendants have been written
//     to cout with the << operator, using a backward in-order
//     traversal. Each node is indented 4 times its depth.
template <class Item, class SizeType>
void printTreeAtDepth (BinaryTreeNode<Item>* node_ptr, SizeType depth)
// Library facilities used: iomanip.h, iostream.h, stdlib.h
{
    if (node_ptr != NULL)
    {
        printTreeAtDepth (node_ptr->right, depth+1);
        cout << setw(4*depth) << ""; // Indent 4*depth spaces
        cout << node_ptr->data << endl;
        printTreeAtDepth (node_ptr->left, depth+1);
    }
}

template <class Item>
void printTree(BinaryTreeNode<Item>* node_ptr)
{
    printTreeAtDepth (node_ptr, 0);
}

template <class Item>
void insert(BinaryTreeNode<Item>*& root_ptr, Item Target) {
    // If the current node is empty (or if the tree is empty)
    if (root_ptr == NULL) {
        root_ptr = create_node(Target);
        // cout << "! - SUCCESSFULLY INSERTED NODE WITH DATA " << Target << endl;
    }
    // If the current node is NOT empty
    else {
        // Check to ensure the Target is not already in the BST
        if (root_ptr->data == Target) {
            cout << "ERROR: Target " << Target << " already exists in tree!" << endl;
            return;
        }
        // If the Target is NOT in the BST already
        else {
            // If Target is greater than the current node, it moves down to its right child
            if (Target > root_ptr->data) {
                insert(root_ptr->right, Target);
            }
            // If Target is less than the current node, it moves down to its left child
            else {
                insert(root_ptr->left, Target);
            }
        }
    }
}

template <class Item>
void remove(BinaryTreeNode<Item>*& root_ptr, Item Target) {
    // First, check to see if the current node is the Target. If so, remove it.
    if (root_ptr != NULL && root_ptr->data == Target) {
        // If the current node is a leaf, it can simply be deleted
        if (is_leaf(*root_ptr) == true) {
            // cout << "! - TARGET FOUND AS LEAF! DELETING NODE." << endl;
            delete root_ptr;
            root_ptr = NULL;
            return;
        }
        // If it has child nodes, we need to replace the node being replaced with its successor.
        else {
            // Declare a pointer to the successor node
            BinaryTreeNode<Item>* successor_ptr;
            // Declare a pointer to the parent of the successor node
            BinaryTreeNode<Item>* successor_parent_ptr = root_ptr;

            // Right child then leftmost child, if there is a right child
            if (root_ptr->right != NULL) {
                // First, get the right child node of the root pointer
                successor_ptr = root_ptr->right;
                // Then, traverse to every left child node until the left-most node is found
                while (successor_ptr->left != NULL) {
                    successor_parent_ptr = successor_ptr;
                    successor_ptr = successor_ptr->left;
                }
                // Now that we know the successor, we need to make sure its right child nodes are not left behind
                BinaryTreeNode<Item>* successor_right_child_ptr = tree_copy(successor_ptr->right);

                // Now comes the part where we actually replace/delete the nodes. 
                // First, set the data of the target node to the successor.
                root_ptr->data = successor_ptr->data;
                // Then, clear the tree at the successor
                tree_clear(successor_ptr);
                // Finally, replace where successor once was with its right child nodes (still NULL if it had none)
                successor_parent_ptr->left = successor_right_child_ptr;
            }

            // If there is no right child, go for left child then rightmost child
            else {
                // First, get the left child node of the root pointer
                successor_ptr = root_ptr->left;
                // Then, traverse to every right child node until the right-most node is found
                while (successor_ptr->right != NULL) {
                    successor_parent_ptr = successor_ptr; 
                    successor_ptr = successor_ptr->right;
                }
                // Now that we know the successor, we need to make sure its left child nodes are not left behind
                BinaryTreeNode<Item>* successor_left_child_ptr = tree_copy(successor_ptr->left);
                
                // Now comes the part where we actually replace/delete the nodes. 
                // First, set the data of the target node to the successor.
                root_ptr->data = successor_ptr->data;
                // Then, clear the tree at the successor
                tree_clear(successor_ptr);
                // Finally, replace where successor once was with its left child nodes (still NULL if it had none)
                successor_parent_ptr->right = successor_left_child_ptr;
            }
        }
    }
    // If the current node does not have the matching data, move onto the next node w/ a recursive call
    else {
        if (root_ptr == NULL) {
            cout << "ERROR: Target " << Target << " could not be found!" << endl;
            return;
        }
        if (Target < root_ptr->data) {
            remove(root_ptr->left, Target);
            return;
        }
        else if (Target > root_ptr->data) {
            remove(root_ptr->right, Target);
            return;
        }
    }
}
// delete is predefined, so we use the name "remove" rather than "delete".

template <class Item>
BinaryTreeNode<Item>* reflect(const BinaryTreeNode<Item>* root_ptr) {
    BinaryTreeNode<Item>* reflect_ptr; // Create a pointer to the tree that will be returned
    // Base case - If the current node is NULL
    if (root_ptr == NULL) {
        reflect_ptr = nullptr;
        return reflect_ptr; // Return a null pointer (empty node)
    }
    // Recursive case
    else {
        // The node reflect_ptr points to will have its left and right nodes flipped
        // Those left and right nodes will also have reflect called on them
        reflect_ptr = create_node(root_ptr->data, reflect(root_ptr->right), reflect(root_ptr->left));
        return reflect_ptr; // Return a pointer to the node
    }
}

template <class Item>
int height(const BinaryTreeNode<Item>* root_ptr) {
    int tree_height;
    // Base case: If the root is null (empty tree)
    if (root_ptr == NULL) {
        tree_height = 0;
        return 0;
    }
    // End Case: If the current node is a leaf, return the tree height = 0;
    else {
        if (is_leaf(*root_ptr) == true) {
            tree_height = 0;
            return tree_height;
        }
        else {
            // If there is one child node, make a recursive call to follow that child node
            if (root_ptr->right == NULL) {
                tree_height = height(root_ptr->left);
                return tree_height + 1;
            }
            else if (root_ptr->left == NULL) {
                tree_height = height(root_ptr->right);
                return tree_height + 1;
            }
            // If there are two child nodes, we need to check every possible path
            else {
                // Find the height going up the left side
                tree_height = height(root_ptr->left);
                // Find the height going up the right side
                int right_tree_height = height(root_ptr->right); 
                // Return whichever height is greater
                if (right_tree_height > tree_height) {
                    tree_height = right_tree_height;
                }
                return tree_height + 1;
            }
        }
    }
}
