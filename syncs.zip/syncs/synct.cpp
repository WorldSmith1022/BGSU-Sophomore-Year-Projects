// Author: Norman Labow
// CS 3080 Project 4
// Due 11/4/22
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>

// Global Definitions

#define NUM_THREADS 6 // 6 Producer Threads, 6 Consumer Threads

#define S 10 // Buffer size S=10

// Global Variables
int buf[S]; // This is our buffer
int NextIn = 0;
int NextOut = 0;
int buf_items = 0; // Number of items in buffer

pthread_mutex_t lock; // Lock the threads
pthread_cond_t empty; // Buffer is empty
pthread_cond_t full; // Buffer is full

int totMin = 0; 
int totMax = 0;
float totAvg = 0.0; // Total Min/Max/Avg variables

int min_arr[NUM_THREADS]; // Arrays of threads' local variables
int max_arr[NUM_THREADS];
float avg_arr[NUM_THREADS];


// User-Input Arguments
int numItems;
int range;

pthread_t ptP[NUM_THREADS]; // Array of producer threads
pthread_t ptC[NUM_THREADS]; // Array of consumer threads

using namespace std;

// Producer Function
void *produce(void *args) {

	// Use ID as seed for RNG
	pthread_t myID = pthread_self();
	srand(myID);

	// Declare Random Number
	int n;

	// Loop for 10 items
	for (int i = 0; i < numItems; ++i) {
		// Generate a random number between 1-Range
		n = ((rand() % range) + 1);

		// Lock the thread
		pthread_mutex_lock(&lock);

		// Wait for the buffer to be empty before unlocking
		while (buf_items >= 10) {
			pthread_cond_wait(&empty, &lock);
		}

		// Add the random number into the buffer
		buf[NextIn++] = n;
		NextIn %= S;
		++buf_items;
		
		// Signal that the buffer is full and unlock the thread
		pthread_cond_signal(&full);
		pthread_mutex_unlock(&lock);
	}
	
	pthread_exit(NULL);
}

// Conumer Function
void *consume(void *args) {

	// Local Min/Max/Sum/Avg variables
	int myMin = 10001;
	int myMax = 0;
	float myAvg = 0.0;
	int myNumItems = 0;

	// Declare number to be retrieved from the buffer
	int n;
	

	// Get thread ID
	intptr_t myID = (intptr_t) args;

	// Loop for as many items as there currently is myNumItems
	while (myNumItems != numItems) {
		
		// Consumer must wait for the producer to signal full
		pthread_mutex_lock(&lock);
		while (buf_items <= 0) {
			pthread_cond_wait(&full, &lock);
		}

		// Get number from the buffer
		n = buf[NextOut++];
		NextOut &= S;
		--buf_items;

		// Check for min/max
		if (n < myMin) { myMin = n; }
		if (n > myMax) { myMax = n; }

		// Update the sum
		myAvg += n;
		++myNumItems;

		// Signal Empty and unlock the thread
		pthread_cond_signal(&empty);
		pthread_mutex_unlock(&lock);
	}
	
	// Update the avg
	myAvg = myAvg / myNumItems;
	
	// Add local variables to global array to be used by parent function
	min_arr[myID] = myMin;
	max_arr[myID] = myMax;
	avg_arr[myID] = myAvg;

	// Print out the consumer's own myMin, myMax, myAvg
	printf("Min: %d, Max: %d, Avg: %5.2f \n", myMin, myMax, myAvg);

	// Exit the thread
	pthread_exit(NULL);
}

// Main Function
int main(int argc, char *argv[]) {
	// Check to ensure all necessary arguments are there
	if (argc != 3) {
		printf("ERROR: Incorrect Number of Arguments! \n");
		return 1;
	}
	// If they are there, use the arguments for numItems and range
	numItems = atoi(argv[1]);
	range = atoi(argv[2]);

	// Initialize Thread Attributes
	pthread_attr_t a;
	pthread_attr_init(&a);

	// Initialize synchronization conditions
	pthread_cond_init(&empty, NULL); // Buffer is empty
	pthread_cond_init(&full, NULL); // Buffer is full
	pthread_mutex_init(&lock, NULL); // Thread is locked
	
	long t;

	// Create six producer and consumer threads each
	for (t = 0; t < NUM_THREADS; ++t) {
		// Create a producer thread
		pthread_create(&ptP[t], NULL, produce, (void *)t);
	}
	for (t = 0; t < NUM_THREADS; ++t) {
		// Create a consumer thread
		pthread_create(&ptC[t], NULL, consume, (void *)t);
	}

	// Join the threads
	for (t = 0; t < NUM_THREADS; ++t) {
		pthread_join(ptP[t], NULL);
	}

	for (t = 0; t < NUM_THREADS; ++t) {
		pthread_join(ptC[t], NULL);
	}

	// Destroy the lock mutex
	pthread_mutex_destroy(&lock);

	// Get total min, max, and avg from array
	totMin = min_arr[0];
	totMax = max_arr[0];
	for (int i = 0; i < NUM_THREADS; ++i) {
		if (min_arr[i] < totMin) {
			totMin = min_arr[i];
		}
		if (max_arr[i] > totMax) {
			totMax = max_arr[i];
		}
		totAvg += avg_arr[i];
	}
	// Compute the average
	totAvg = totAvg / NUM_THREADS;

	// Report the total min, max, and avg
	printf("Total Min: %d \n", totMin);
	printf("Total Max: %d \n", totMax);
	printf("Total Average: %5.2f \n", totAvg);

	return 0;
}
